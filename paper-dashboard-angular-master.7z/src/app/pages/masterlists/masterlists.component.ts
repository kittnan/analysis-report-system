import { Component, OnInit } from '@angular/core';

import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { data } from 'jquery';
import { getMaxListeners } from 'process';
import { MasterlistsService } from '../masterlists/masterlists.service';

@Component({
    selector: 'app-masterlists',
    templateUrl: './masterlists.component.html',
    styleUrls: ['./masterlists.component.css'],


})


export class MasterlistsComponent implements OnInit {

    // ! control HTML
    selectedMaster: any;
    listAdd: any;
    masterAdd: any;
    masterDel: any;
    keySearch: any;
    tt: any;
    permissionUserAdd: any;
    permissionLevelAdd: any;

    keyEdit: any;
    keyIdEdit: any;

    keyDelete: any;
    keyIdDelete: any;

    keyPermissionId: any;
    keyPermissionEdit: any;
    keyPermissionLevel: any;

    // todo use in function
    closeResult: string;
    listMasterAll: any;
    listAll: any;
    searchList: any;
    permissionShow: any;


    tets: any;
    testpush: any;

    constructor(private modalService: NgbModal, private masterlist: MasterlistsService) { }
    openLg(content, title, id) {
        this.modalService.open(content, { size: 'lg' });

        // เก็บ key btn
        this.keyEdit = title;
        this.keyIdEdit = id;

        this.keyDelete = title;
        this.keyIdDelete = id;

        this.masterDel = this.selectedMaster;

    }

    ngOnInit(): void {
        this.getMaster();
    }


    // todo USE
    getMaster() {
        this.masterlist.getMaster().subscribe((data: any) => {
            if (data) {
                this.listMasterAll = data; // รับ List Master All มา
            } else {
                location.reload();
            }
        })
    }

    selectMaster() {

        if (this.selectedMaster == "PermissionUser") {
            this.keySearch = null;
            let Data = {
                master: "PermissionUser"
            }
            this.masterlist.selectMaster(Data).subscribe((data: any) => {
                if (data) {
                    this.listAll = data;
                    this.permissionShow = true;
                } else {
                    location.reload();
                }

            })
        } else {

            this.keySearch = null;
            let Data = {
                master: this.selectedMaster
            }
            this.masterlist.selectMaster(Data).subscribe((data: any) => {
                if (data) {
                    this.listAll = data;
                    this.permissionShow = false;
                } else {
                    location.reload();
                }

            })
        }

    }

    // ? --------------------------------- Master -------------------------------------------------------
    AddMaster() {

        // !OK
        if (this.masterAdd != null) {

            let Data = {
                master: this.masterAdd
            }
            this.masterlist.AddMaster(Data).subscribe((data: any) => {
                console.log(data);
                if (data) {
                    alert("SUCCESS");
                    this.getMaster();
                    location.reload();

                }

            })

        } else {
            alert("Pls Check FORM");
        }


    }


    DelMaster() {
        let Data = {
            master: this.masterDel
        }
        this.masterlist.DelMaster(Data).subscribe((data: any) => {
            if (data) {
                alert("SUCCESS");
                this.masterDel = null;
                this.getMaster();
                location.reload();

            }
        })
    }

    // ? --------------------------------- Master -------------------------------------------------------


    // ? --------------------------------- List -------------------------------------------------------

    AddList() {

        // ! OK
        let Data = {
            master: this.selectedMaster,
            list: this.listAdd
        }
        this.masterlist.AddList(Data).subscribe((data: any) => {
            if (data) {
                this.selectMaster();
                alert("SUCCESS");

            }
        })

    }

    DelList() {
        let Data = {
            master: this.selectedMaster,
            list: this.keyDelete
        }
        this.masterlist.DelList(Data).subscribe((data: any) => {
            if (data) {
                this.selectMaster();
                alert("SUCCESS");
            }
        })
    }

    EditList() {
        let Data = {
            _id: this.keyIdEdit,
            list: this.keyEdit
        }
        console.log(Data);
        this.masterlist.EditList(Data).subscribe((data: any) => {
            if (data) {
                this.selectMaster();
                alert("SUCCESS");
            }
        })
    }

    Search() {
        console.log(this.keySearch);
        let Data = {
            master: this.selectedMaster,
            key: this.keySearch
        }
        this.masterlist.searchList(Data).subscribe((data: any) => {
            if (data) {
                if (data == null) {
                    this.tt = false;

                } else {
                    this.searchList = data;
                    this.tt = true;
                }
            }
        })
    }


    // ? --------------------------------- List -------------------------------------------------------

    // ! -------------------------------- Permission  --------------------------------------------

    onClickPermission(id, user, level) {
        this.keyPermissionId = id;
        this.keyPermissionEdit = user;
        this.keyPermissionLevel = level;
        console.log(this.keyPermissionEdit + "| " + this.keyPermissionId);
    }

    onAddPermission() {
        let Data = {
            user: this.permissionUserAdd,
            level: this.permissionLevelAdd
        }
        console.log(Data);
        this.masterlist.addPermissionUser(Data).subscribe((data:any)=>{
            if(data){
                alert("SUCCESS");
                this.selectMaster();

            }
        })
    }


    onEditPermission() {

        let Data = {
            _id: this.keyPermissionId,
            user: this.keyPermissionEdit,
            level: this.keyPermissionLevel
        }
        console.log(Data);
        this.masterlist.editPermissionUser(Data).subscribe((data: any) => {
            if (data) {
                alert('SUCCESS');
                this.selectMaster();
            }
        })

    }

    onDeletePermission() {
        let Data = {
            _id: this.keyPermissionId
        }
        console.log(Data);
        this.masterlist.deletePermissionUser(Data).subscribe((data: any) => {
            if (data) {
                alert("SUCCESS");
                this.selectMaster();
            }
        })
    }
}