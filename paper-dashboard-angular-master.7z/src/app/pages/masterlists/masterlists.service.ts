import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class MasterlistsService {

  constructor(private http: HttpClient) { }

  // todo Master - v -
  getMaster(): Observable<any> {
    return this.http.get("http://localhost:4013/getMasterList");
  }
  AddMaster(data: any): Observable<any> {
    return this.http.post("http://localhost:4013/AddMaster", data);
  }
  DelMaster(data: any): Observable<any> {
    return this.http.post("http://localhost:4013/DelMaster", data);
  }
  
// todo List -v-
  AddList(data: any): Observable<any> {
    return this.http.post("http://localhost:4013/AddList", data);
  }
  DelList(data: any): Observable<any> {
    return this.http.post("http://localhost:4013/DelList", data);
  }
  EditList(data: any): Observable<any> {
    return this.http.post("http://localhost:4013/EditList", data);
  }

  // ? get list -v-
  selectMaster(path: any): Observable<any> {
    return this.http.post("http://localhost:4013/getList", path);
  }
  
 
  searchList(data: any): Observable<any> {
    return this.http.post("http://localhost:4013/SearchList", data);
  }


  addPermissionUser(data: any): Observable<any> {
    return this.http.post("http://localhost:4013/addPermissionUser", data);
  }
  editPermissionUser(data: any): Observable<any> {
    return this.http.post("http://localhost:4013/editPermissionUser", data);
  }

  deletePermissionUser(data: any): Observable<any> {
    return this.http.post("http://localhost:4013/deletePermissionUser", data);
  }
}

