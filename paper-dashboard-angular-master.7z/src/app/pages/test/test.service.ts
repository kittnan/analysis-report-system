import { Injectable } from '@angular/core';
import { HttpClient, HttpRequest, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class TestService {
  constructor(private http: HttpClient) { }

 

  async uploadBannerIamge(file: any) {
    // const headers = new HttpHeaders().set('x-access-token', this.token);
    return new Promise((resolve, reject) => {
      const uploadData = new FormData();
      uploadData.append('fileimg', file);
      this.http
        .post("http://localhost:4013/upload", uploadData,)
        .subscribe(
          (data) => {
            resolve(data);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }
}
