import { Component, OnInit } from '@angular/core';
import { HttpEventType, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { TestService } from './test.service';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {


  constructor(private fileUploadService: TestService) { }

  imageSrc: any;
  imgPath: any  = "http://127.0.0.1";
  imga: any;

  async handleFileInput(el: any) {
    var file = el.dataTransfer ? el.dataTransfer.files[0] : el.target.files[0];
    console.log(file);

    // const uploadData = new FormData();
    // uploadData.append('fileimg', file);

    // if (file.size <= 11154) {
      await this.fileUploadService.uploadBannerIamge(file).then((data: any) => {
        localStorage.setItem('Img', data)
        this.imageSrc = this.imgPath + data;
        this.imga = data;
        console.log("callback: " +this.imageSrc);
        
      })
    // } else {

      // this.operalert()
    // }

  }

  

  ngOnInit(): void {

  }

}
