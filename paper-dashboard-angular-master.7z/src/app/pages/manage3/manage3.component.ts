import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage3',
  templateUrl: './manage3.component.html',
  styleUrls: ['./manage3.component.css']
})
export class Manage3Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
