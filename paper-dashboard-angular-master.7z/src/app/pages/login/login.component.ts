import { Component, OnInit } from '@angular/core';
import { LoginService } from './login.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  username: any;
  password: any;
  userLogin: any;

  // ? get session store
  userId: any;
  userFname: any;
  userLname: any;
  userSection: any;
  userEmpCode: any;
  userEmail: any;
  userStatus:any;
  // loginStatus : any = sessionStorage.getItem('loginStatus'); 

  constructor(private login: LoginService) { }

  ngOnInit(): void {
    this.userLogin = sessionStorage.getItem('loginStatus');
    this.userId = sessionStorage.getItem('userId');
    this.userFname = sessionStorage.getItem('userFname');
    this.userLname = sessionStorage.getItem('userLname');
    this.userSection = sessionStorage.getItem('userSection');
    this.userEmpCode = sessionStorage.getItem('EmpCode');
    this.userEmail = sessionStorage.getItem('userEmail');
  }

  onSubmit() {
    if (this.username != "" && this.username != null && this.password != "" && this.password != null) {

      let Data = {
        username: this.username,
        password: this.password
      }
      // console.log(this.username);
      // console.log(this.password);
      this.login.postLogin(Data).subscribe((data) => {
        if (data.length > 0) {

          if(data[0].Section == "USER1"){
            this.userStatus = 1 ;
          }
          if(data[0].Section == "USER2"){
            this.userStatus = 2 ;
          }
          if(data[0].Section == "USER3"){
            this.userStatus = 3 ;
          }
          if(data[0].Section == "USER4"){
            this.userStatus = 4 ;
          }
          if(data[0].Section == "USER5"){
            this.userStatus = 5 ;
          }
          if(data[0].Section == "USER6"){
            this.userStatus = 6 ;
          }
          if(data[0].Section == "ENG1"){
            this.userStatus = 5 ;
          }
          if(data[0].Section == "admin"){
            this.userStatus = 0 ;
          }

          // console.log(data[0] != null);
          this.userLogin = true;

          sessionStorage.setItem('userId', data[0]._id);
          sessionStorage.setItem('userFname', data[0].Fname);
          sessionStorage.setItem('userLname', data[0].Lname);
          sessionStorage.setItem('userSection', data[0].Section);
          sessionStorage.setItem('userEmail', data[0].Email);
          sessionStorage.setItem('EmpCode', data[0].EmpCode);
          sessionStorage.setItem('loginStatus', this.userLogin);
          sessionStorage.setItem('userStatus', this.userStatus);

          this.userId = sessionStorage.getItem('userId');
          this.userFname = sessionStorage.getItem('userFname');
          this.userLname = sessionStorage.getItem('userLname');
          this.userSection = sessionStorage.getItem('userSection');
          this.userEmpCode = sessionStorage.getItem('EmpCode');
          this.userEmail = sessionStorage.getItem('userEmail');
          // alert("Login SUCCESS");
          console.log("user: " + sessionStorage.getItem('userFname'));
          this.username = "";
          this.password = "";
          location.href = "/#manageForm";
        } else {
          alert("Login Fail");
        }
      })
    } else {
      alert("Login Fail");
    }
  }

  onLogout() {
    sessionStorage.clear();
    this.userLogin = false;
    // alert("Logout");
  }

}
