import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage6',
  templateUrl: './manage6.component.html',
  styleUrls: ['./manage6.component.css']
})
export class Manage6Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
