import { Component, OnInit } from '@angular/core';
import { ProgressForm4Service } from './progress-form4.service';
@Component({
  selector: 'app-progress-form4',
  templateUrl: './progress-form4.component.html',
  styleUrls: ['./progress-form4.component.css']
})
export class ProgressForm4Component implements OnInit {
  dataProgress: any;
  userStatus: any;
  formStatus: any;
  
  constructor(private progressForm4: ProgressForm4Service) { }

  ngOnInit(): void {
    let Data = {
      title: sessionStorage.getItem('numberProgress1')
    }
    this.progressForm4.getProgressForm1(Data).subscribe((data) => {

      // console.log(">> " +data[0]);
      if (data) {
        this.dataProgress = data[0];
        this.formStatus = data[0].status;
        this.userStatus = sessionStorage.getItem('userStatus');

      }
    })
  }

  submitForm(e) {
    // ? ดัก สเตตัสของ ฟอร์ม
    if (this.formStatus != 5) {

      if (e.value == "approve") {
        let Data = {
          requestNumber: sessionStorage.getItem('numberProgress1'),
          status: 5
        }
        this.progressForm4.submitProgress(Data).subscribe((data: any) => {
          if (data) {
            alert("OK Status 5");
            location.href = "/#manageForm";
          }
        })
      } 

      if (e.value == "reject") {
        let Data = {
          requestNumber: sessionStorage.getItem('numberProgress1'),
          status: 4
        }
        this.progressForm4.submitProgress(Data).subscribe((data: any) => {
          if (data) {
            alert("ENG reject to 4");
            location.href = "/#manageForm";
          }
        })
      }

    }
  }
}
