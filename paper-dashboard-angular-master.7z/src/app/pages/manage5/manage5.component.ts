import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage5',
  templateUrl: './manage5.component.html',
  styleUrls: ['./manage5.component.css']
})
export class Manage5Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
