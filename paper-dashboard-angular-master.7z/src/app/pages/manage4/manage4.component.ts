import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage4',
  templateUrl: './manage4.component.html',
  styleUrls: ['./manage4.component.css']
})
export class Manage4Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
