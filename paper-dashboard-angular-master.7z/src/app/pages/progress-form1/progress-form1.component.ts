import { Component, Input, OnInit } from '@angular/core';
import { ProgressForm1Service } from './progress-form1.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-progress-form1',
  templateUrl: './progress-form1.component.html',
  styleUrls: ['./progress-form1.component.css']
})
export class ProgressForm1Component implements OnInit {

  dataProgress: any;
  submitProgressForm: any;
  userStatus: any;
  formStatus:any;

  // requestNumber:any;
  constructor(private progressForm1: ProgressForm1Service, private router: Router) { }

  ngOnInit(): void {
    this.userStatus = sessionStorage.getItem('userStatus');
    if (this.userStatus == "2" || this.userStatus == "1") {

      let Data = {
        title: sessionStorage.getItem('numberProgress1')
      }
      this.progressForm1.getProgressForm1(Data).subscribe((data) => {

        if (data) {
          this.dataProgress = data[0];
          // console.log(this.dataProgress);
          this.formStatus = this.dataProgress.status;
          // console.log("item Stat: " + this.dataProgress.status)
        }
      })
    }


  }

  submitForm(e) {
    if (e.value == "reject") {
      let Data = {
        requestNumber: sessionStorage.getItem('numberProgress1'),
        status: 2.1
      }
      this.progressForm1.submitProgress(Data).subscribe((data: any) => {
        if (data) {
          alert("reject 2.1 not ready");
        }
      })
    } else {
      let Data = {
        requestNumber: sessionStorage.getItem('numberProgress1'),
        status: 2
      }
      this.progressForm1.submitProgress(Data).subscribe((data: any) => {
        if (data) {
          alert("SUCCESS");
          location.href = "/#manageForm";
        }
      })
    }
  }

}
