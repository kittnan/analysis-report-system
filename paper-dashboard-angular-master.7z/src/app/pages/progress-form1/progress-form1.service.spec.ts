import { TestBed } from '@angular/core/testing';

import { ProgressForm1Service } from './progress-form1.service';

describe('ProgressForm1Service', () => {
  let service: ProgressForm1Service;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ProgressForm1Service);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
