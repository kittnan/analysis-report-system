import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProgressForm1Component } from './progress-form1.component';

describe('ProgressForm1Component', () => {
  let component: ProgressForm1Component;
  let fixture: ComponentFixture<ProgressForm1Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProgressForm1Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProgressForm1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
