import { TestBed } from '@angular/core/testing';

import { ProgressForm6Service } from './progress-form6.service';

describe('ProgressForm6Service', () => {
  let service: ProgressForm6Service;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ProgressForm6Service);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
