import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProgressForm6Service {

  constructor(private http: HttpClient) { }
  
  getProgressForm1(data:any): Observable<any>{
    return this.http.post("http://localhost:4013/getProgressForm1",data);
  }
  submitReport(data:any): Observable<any>{
    return this.http.post("http://localhost:4013/submitReport",data);
  }
  getEng(data:any): Observable<any>{
    return this.http.post("http://localhost:4013/getEng",data);
  }

  findReportSelect(data:any): Observable<any>{
    return this.http.post("http://localhost:4013/findReportSelect", data);
  }
  findFilePath(data:any): Observable<any>{
    return this.http.post("http://localhost:4013/findFilePath", data);
  }
  findInform(data:any): Observable<any>{
    return this.http.post("http://localhost:4013/findInform", data);
  }

  


  submitProgress(data:any): Observable<any>{
    return this.http.post("http://localhost:4013/submitProgress",data);
  }
}
