import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProgressForm6Component } from './progress-form6.component';

describe('ProgressForm6Component', () => {
  let component: ProgressForm6Component;
  let fixture: ComponentFixture<ProgressForm6Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProgressForm6Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProgressForm6Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
