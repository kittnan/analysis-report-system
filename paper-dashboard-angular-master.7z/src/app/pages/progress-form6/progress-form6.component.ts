import { Component, OnInit } from '@angular/core';
import { ProgressForm6Service } from './progress-form6.service';
@Component({
  selector: 'app-progress-form6',
  templateUrl: './progress-form6.component.html',
  styleUrls: ['./progress-form6.component.css']
})
export class ProgressForm6Component implements OnInit {

  constructor(private progressForm6: ProgressForm6Service) { }
  dataProgress: any;
  reportResult: any;
  filePath: any ;
  inform: any ;
  memberAll: any;
  userStatus: any;
  formStatus: any;

  ngOnInit(): void {
    let Data = {
      title: sessionStorage.getItem('numberProgress1')
    }
    this.progressForm6.getProgressForm1(Data).subscribe((data) => {

      if (data) {
        this.dataProgress = data[0];
        console.log(this.dataProgress.issueData)
        this.formStatus = data[0].status;
        this.userStatus = sessionStorage.getItem('userStatus');

        this.findReportAll();

      }
    })
  }

  onSubmit(){
   
    if(this.formStatus == 6){
      let Data = {
        requestNumber:sessionStorage.getItem('numberProgress1'),
        status: 7
      }
      this.progressForm6.submitProgress(Data).subscribe((data: any) => {
        if (data) {
          alert("OK Status 7");
          location.href = "/#manageForm";
        }
      })
    }
  }

  findReportAll() {

    let Data = {
      title: this.dataProgress.requestNumber
    }

    this.progressForm6.findReportSelect(Data).subscribe((data: any) => {
      if (data) {
        this.reportResult = data[0];
        this.findFile();
        this.findInform();
      }
    })
  }

  findFile() {
    let Data = {
      title: this.reportResult.analysisReportNo
    }
    this.progressForm6.findFilePath(Data).subscribe((data:any) => {
      console.log(data[0]);
      this.filePath = data;
    })
  }

  findInform() {
    let Data = {
      title: this.reportResult.analysisReportNo
    }
    this.progressForm6.findInform(Data).subscribe((data:any) => {
      console.log(data[0]);
      this.inform = data;
    })
  }

}
