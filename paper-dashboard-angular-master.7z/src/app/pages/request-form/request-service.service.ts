import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class RequestServiceService {

  constructor(private http: HttpClient) { }

  getRI(data: any): Observable<any> {
    return this.http.post("http://localhost:4013/getRI", data);
  }
  postMaster(data: any): Observable<any> {
    return this.http.post("http://localhost:4013/postMaster", data);
  }
  postRequestForm(data: any): Observable<any> {
    return this.http.post("http://localhost:4013/requestForm", data);
  }
  findRequestForm(data:any):Observable<any> {
    return this.http.post("http://localhost:4013/findRequestForm", data);
  }

  async uploadImage(file: any , name:any) {
    // const headers = new HttpHeaders().set('x-access-token', this.token);
    return new Promise((resolve, reject) => {
      const uploadData = new FormData();
      // uploadData.append('fileimg', file);
      uploadData.append('fileimg', file , name +".jpg");
      this.http
        .post("http://localhost:4013/upload", uploadData,)
        .subscribe(
          (data) => {
            resolve(data);
          },
          (err) => {
            reject(err);
          }
        );
    });
  }

}
