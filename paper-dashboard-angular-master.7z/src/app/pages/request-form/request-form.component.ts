import { Component, OnInit } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { data } from 'jquery';
import * as moment from 'moment';
import { cpuUsage, getMaxListeners } from 'process';
import { RequestServiceService } from './request-service.service';
@Component({
  selector: 'app-request-form',
  templateUrl: './request-form.component.html',
  styleUrls: ['./request-form.component.css']
})

export class RequestFormComponent implements OnInit {

  // ? เก็บ list
  requestItem: any;
  ktcModelNumber: any;
  defectName: any;
  productPhase: any;
  defectCategory: any;
  abnormalLevel: any;
  occurA: any;
  occurB: any;
  // minDate : any = moment(new Date()). format('YYYY-MM-DD');

  //  ? เก็บ ค่าจาก html
  htmlRequestItem: any;
  htmlRequestNumber: any;
  tempRequestNumber:any;
  htmlKtcModelNumber: any;
  htmlDefectiveName: any;
  htmlPcLotNumber: any;
  htmlInputQuantity: any;
  htmlNgQuantity: any;
  htmlNgRatio: any;
  htmlSendNgToAnalysis: any;
  htmlProductionPhase: any;
  htmlDefectCatagory: any;
  htmlAbnormalLotLevel: any;
  htmlOccurPlaceA: any;
  htmlOccurPlaceB: any;
  htmlImage: any;

  // ? date
  htmlDate1: any;
  htmlDate2: any;
  dateToDay: any = {
    year: new Date().getFullYear(),
    month: new Date().getMonth() + 1,
    day: new Date().getDate()
  };
  minPickerDate: any = {
    year: new Date().getFullYear(),
    month: new Date().getMonth() + 1,
    day: new Date().getDate()
  };
  // ? image
  imageSrc: any;
  imgPath: any = "http://127.0.0.1";
  imga: any;
  fileTemp: any;

  // ? image upload
  fileToUpView: any;
  imageUrl: any;

  // ? sessionStore
  userSection: any = sessionStorage.getItem('userSection');
  // userLogin: any  = sessionStorage.getItem('userId');

  constructor(private modalService: NgbModal, private requestForm: RequestServiceService) { }

  ngOnInit(): void {

    this.userSection = sessionStorage.getItem('userSection');

//  * --------------------------------------Check Login 
  
    if (!this.userSection) {
      alert("Pls Login");
      location.href = "/#/login";
    }
//  * --------------------------------------Check Login 


//  * --------------------------------------Get Variable  

    // this.getRequestItem();
    this.postMaster("Request Item");
    this.postMaster("KTC Model Number");
    this.postMaster("Defective Name");
    this.postMaster("Production Phase");
    this.postMaster("Defect Category");
    this.postMaster("Abnormal Lot Level");
    this.postMaster("Occur Place A");
    this.postMaster("Occur Place B");
    // this.htmlRequestNumber = "38RCPL";
//  * --------------------------------------Get Variable 

    // console.log("user: " + this.userSection);

  }


//  * --------------------------------------Function Get Variable 
  postMaster(key) {
    let Data = {
      master: key
    }
    this.requestForm.postMaster(Data).subscribe((data: any) => {
      if (data) {
        // console.log(data);
        if (key == "Request Item") {
          this.requestItem = data;
        }
        if (key == "KTC Model Number") {
          this.ktcModelNumber = data;
        }
        if (key == "Defective Name") {
          this.defectName = data;
        }
        if (key == "Production Phase") {
          this.productPhase = data;
        }
        if (key == "Defect Category") {
          this.defectCategory = data;
        }
        if (key == "Abnormal Lot Level") {
          this.abnormalLevel = data;
        }
        if (key == "Occur Place A") {
          this.occurA = data;
        }
        if (key == "Occur Place B") {
          this.occurB = data;
        }

      }
    })
  }
//  * --------------------------------------Function Get Variable 



  onSubmit() {

    // ? check input form is not empty
    if (this.htmlRequestItem != null && this.htmlRequestNumber != null && this.htmlDate1 != null
      && this.htmlKtcModelNumber != null && this.htmlDefectiveName != null && this.htmlPcLotNumber != null
      && this.htmlInputQuantity != null && this.htmlNgQuantity != null && this.htmlNgRatio != null
      && this.htmlSendNgToAnalysis != null && this.htmlProductionPhase != null && this.htmlDefectCatagory != null
      && this.htmlAbnormalLotLevel != null && this.htmlOccurPlaceA != null && this.htmlOccurPlaceB != null
      && this.htmlImage != null) {
      console.log("SUBMIT OK");

      // * -------------------------- post Request Form when not image
      if (this.fileTemp == null) {
        let Data = {
          requestItem: this.htmlRequestItem,
          requestNumber: this.htmlRequestNumber,
          requestFormSection: sessionStorage.getItem('userSection'),
          issuedDate: this.htmlDate1,
          replyDate: this.htmlDate2,
          ktcModelNumber: this.htmlKtcModelNumber,
          defectiveName: this.htmlDefectiveName,
          pcLotNumber: this.htmlPcLotNumber,
          inputQuantity: this.htmlInputQuantity,
          ngQuantity: this.htmlNgQuantity,
          ngRatio: this.htmlNgRatio,
          sendNgAnalysis: this.htmlSendNgToAnalysis,
          productionPhase: this.htmlProductionPhase,
          defectCatagory: this.htmlDefectCatagory,
          abnormalLotLevel: this.htmlAbnormalLotLevel,
          occurA: this.htmlOccurPlaceA,
          occurB: this.htmlOccurPlaceB,
          picture: this.imageSrc
        }

        this.requestForm.postRequestForm(Data).subscribe((data: any) => {
          if (data) {
            alert("Submit Success");
            location.reload();
          } else {
            alert("Submit Fail");
            location.reload();
          }
        })
      // * -------------------------- post Request Form when not image


      // * -------------------------- upload image when have image

      } else {

        var file = this.fileTemp.dataTransfer ? this.fileTemp.dataTransfer.files[0] : this.fileTemp.target.files[0];
        let name = this.htmlRequestNumber;
        this.requestForm.uploadImage(file, name).then((data: any) => {

          if (data) {

            localStorage.setItem('Img', data)
            this.imageSrc = this.imgPath + data;
            this.imga = data;

            // ? post Request Form
            let Data = {
              requestItem: this.htmlRequestItem,
              requestNumber: this.htmlRequestNumber,
              issuedDate: this.htmlDate1,
              requestFormSection: sessionStorage.getItem('userSection'),
              ktcModelNumber: this.htmlKtcModelNumber,
              defectiveName: this.htmlDefectiveName,
              pcLotNumber: this.htmlPcLotNumber,
              inputQuantity: this.htmlInputQuantity,
              ngQuantity: this.htmlNgQuantity,
              ngRatio: this.htmlNgRatio,
              sendNgAnalysis: this.htmlSendNgToAnalysis,
              productionPhase: this.htmlProductionPhase,
              defectCatagory: this.htmlDefectCatagory,
              abnormalLotLevel: this.htmlAbnormalLotLevel,
              occurA: this.htmlOccurPlaceA,
              occurB: this.htmlOccurPlaceB,
              issueData: sessionStorage.getItem('userFname'),
              picture: this.imageSrc,
              status: 1
            }

            console.log(Data)
            this.requestForm.postRequestForm(Data).subscribe((data: any) => {
              if (data) {
                alert("Submit Success");
                location.reload();
              } else {
                alert("Submit Fail");
                location.reload();
              }
            })
          } else {
            alert("Submit Fail");
            location.reload();

          }

        })
      } 
      // * -------------------------- upload image when have image

    } else {

      // alert("You not fill complete")
      window.scroll(0, 0);
    }

  }

  // ? Cal NG_Ratio
  ngRatio() {
    if (this.htmlInputQuantity != null && this.htmlNgQuantity != null) {
      this.htmlNgRatio = (this.htmlNgQuantity / this.htmlInputQuantity) * 100;
    }
  }

  //  ? preview image
  handleFileInput(file: FileList, event) {
    this.fileToUpView = file.item(0);
    this.fileTemp = event;
    //Show image preview
    let reader = new FileReader();
    reader.onload = (event: any) => {
      this.imageUrl = event.target.result;
    }
    reader.readAsDataURL(this.fileToUpView);
  }

  // ? cancle Image

  delImage() {
    this.imageUrl = "";
    this.htmlImage = null;
    this.fileTemp = null;
  }

  onRequestFormChange() {
    // console.log(this.htmlRequestNumber);
    let Data = {
      requestItem: this.htmlRequestItem + "-" + this.dateToDay.year
    }
    this.requestForm.findRequestForm(Data).subscribe((data: any) => {
      if (data != "") {
        let count = data[data.length - 1].requestNumber;
        let arrayNum = count.split("-");
        // let longNum = arrayNum[2].length;
        let Num  = + arrayNum[2] + 1;
        let Str = "" + Num ;
        let NewItem= "";

        if(Str.length == 1){
          NewItem = "000" + Str ;
        }
        if(Str.length == 2){
          NewItem = "00" + Str ;
        }
        if(Str.length == 3){
          NewItem = "0" + Str ;
        }

        this.htmlRequestNumber = this.htmlRequestItem + "-" + this.dateToDay.year + "-" + NewItem ;
      } else {
        this.htmlRequestNumber = this.htmlRequestItem + "-" + this.dateToDay.year + "-" + "0001" ;

      }



    })
  }

  checkNumber() {

    if (this.htmlPcLotNumber < 0) {
      this.htmlPcLotNumber = null;
    }
    if (this.htmlInputQuantity < 0) {
      this.htmlInputQuantity = null;
    }
    if (this.htmlNgQuantity < 0) {
      this.htmlNgQuantity = null;
    }
    if (this.htmlSendNgToAnalysis < 0) {
      this.htmlSendNgToAnalysis = null;
    }
  }



}
