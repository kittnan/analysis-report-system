import { Component, OnInit } from '@angular/core';
import { ManageFormService } from './manage-form.service';


@Component({
  selector: 'app-manage-form',
  templateUrl: './manage-form.component.html',
  styleUrls: ['./manage-form.component.css'],
  // template:'<app-progress-form1 [a]="SS"></app-progress-form1>'
})

export class ManageFormComponent implements OnInit {

  getRequestItem: any;
  htmlRequestItem: any;
  getForm: any;
  tempForm:any;
  tempForm2:any;

  progressStat: any;
  formPath: any;

  htmlFormClick: any;
  formStatus: any;
  userStatus: any;
  engName: any;
  constructor(private manageForm: ManageFormService) { }

  ngOnInit(): void {

    // todo  set User Level
    this.userStatus = sessionStorage.getItem('userStatus');
    this.engName = sessionStorage.getItem("userFname");
    console.log("US: " + this.userStatus);
    // todo  set User Level
    this.manageForm.getRequestItem().subscribe((data: any) => {
      if (data) {
        this.getRequestItem = data; // รับ List Master All มา
        // console.log(data);

        //  ? query form all when open page
        this.getFormAll();



      } else {
        location.reload();
      }
    })
  }

  onSelect() {
    if (this.htmlRequestItem != null) {

      // ? selected all 
      if (this.htmlRequestItem == "all") {
        this.getFormAll();
      } else {

        // ? selected any
        let Data = {
          title: this.htmlRequestItem
        }
        this.manageForm.getForm(Data).subscribe((data: any) => {
          if (data) {
            this.getForm = data;
            this.formStatus = data[0].status;
            console.log("FS: " + this.formStatus);

          } else {
            location.reload();
          }
        })
      }

    }
  }

  checkStatus(item: any) {

    

    console.log("CLICK:" + item._id)
    if (item.status == 1 && this.userStatus == 1) {
      this.formPath = "/#/progressForm1";
    }
    if (item.status == 1 && this.userStatus == 2) {
      this.formPath = "/#/progressForm1";
    }


    if (item.status == 2 && this.userStatus == 2) {
      this.formPath = "/#/progressForm1";
    }
    if (item.status == 2 && this.userStatus == 3) {
      this.formPath = "/#/progressForm2";
    }


    if (item.status == 3 && this.userStatus == 3) {
      this.formPath = "/#/progressForm2";
    }
    if (item.status == 3 && this.userStatus == 4) {
      this.formPath = "/#/progressForm3";
    }

    if (item.status == 4 && this.userStatus == 4) {
      this.formPath = "/#/progressForm3";
    }
    if (item.status == 4 && this.getForm[0].engineer == this.engName) {
      this.formPath = "/#/progressForm4";
    }

    if (item.status == 5 && this.getForm[0].engineer == this.engName) {
      this.formPath = "/#/progressForm5";
    }
    if (item.status == 6 && this.userStatus == 6) {
      this.formPath = "/#/progressForm6";
    }
    console.log("Path: " + this.formPath);




    sessionStorage.setItem('numberProgress1', item.requestNumber);
  }

  getFormAll() {
    this.manageForm.FormAll().subscribe((data: any) => {
      if (data) {
        this.getForm = data;
        this.tempForm =  data;
        this.tempForm2 =  this.tempForm;
        this.formStatus = data[0].status;
        // this.setRequestNumberYear();

        // let test = "0009";
        // let a = + test +1;
        // let s = "" + a ;
        // console.log(s.length);
        // if(s.length == 2){
        //   console.log("00" + s);
        // }
      }
    })
  }


}
