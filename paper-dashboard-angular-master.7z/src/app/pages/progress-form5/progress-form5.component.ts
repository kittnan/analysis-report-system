import { Component, OnInit } from '@angular/core';
import { ProgressForm5Service } from './progress-form5.service';
@Component({
  selector: 'app-progress-form5',
  templateUrl: './progress-form5.component.html',
  styleUrls: ['./progress-form5.component.css']
})
export class ProgressForm5Component implements OnInit {

  // ? html control

  htmlReportNo: any;
  htmlCaseOfDefect: any;
  htmlSourceOfDefect: any;
  htmlAnalysisLevel: any;
  htmlInform: any;
  htmlResultForm: any;

  dataProgress: any;
  memberAll: any;
  userStatus: any;
  formStatus: any;

  listCaseOfDefect: any;
  listSourceOfDefect: any;
  listAnalysislevel: any;
  listInform: any;

  emailPush: any = [];
  fileUpload: any = [];
  fileName: any = [];

  optionYear: any = { year: '2-digit' }
  year2dit: any;
  dateToDay: any = {
    year: new Date().getFullYear(),
    month: new Date().getMonth() + 1,
    day: new Date().getDate()
  };
  constructor(private progressForm5: ProgressForm5Service) { }

  ngOnInit(): void {


    let Data = {
      title: sessionStorage.getItem('numberProgress1')
    }
    this.progressForm5.getProgressForm1(Data).subscribe((data) => {

      if (data) {
        this.dataProgress = data[0];
        this.formStatus = data[0].status;
        this.userStatus = sessionStorage.getItem('userStatus');

        this.setAnalysisNo();
        this.getList("Cause Of Defect");
        this.getList("Source Of Defect");
        this.getList("Analysis Level");

        this.findMemberAll();

      }
    })
  }

  getList(key: any) {
    let Data = {
      master: key
    }
    this.progressForm5.getLists(Data).subscribe((data: any) => {
      if (key == "Cause Of Defect") {
        this.listCaseOfDefect = data;
      }
      if (key == "Source Of Defect") {
        this.listSourceOfDefect = data;
      }
      if (key == "Analysis Level") {
        this.listAnalysislevel = data;
      }

    })
  }

  onSubmit() {
    let Data = {
      requestNumber: sessionStorage.getItem('numberProgress1'),
      analysisReportNo: this.htmlReportNo,
      analysisResult: this.htmlResultForm,
      causeOfDefect: this.htmlCaseOfDefect,
      sourceOfDefect: this.htmlSourceOfDefect,
      analysisLevel: this.htmlAnalysisLevel

    }
    // console.log("all data" + Data)
    this.progressForm5.submitReport(Data).subscribe((data: any) => {
      if (data) {
        this.upLoadFiles();
        let Data = {
          requestNumber: sessionStorage.getItem('numberProgress1'),
          status: 6
        }
        this.progressForm5.submitProgress(Data).subscribe((data: any) => {
          if(data){
            

            this.submitInform();
            location.href = "/#manageForm";
          }
        })
      }
    })

  }

  setAnalysisNo() {
    this.year2dit = new Date().toLocaleDateString("en-US", this.optionYear);
    this.progressForm5.findReport().subscribe((data: any) => {
      let item = "";
      if (this.dataProgress.requestItem == "PNL") {
        item = "P";
      }
      if (this.dataProgress.requestItem == "MDL") {
        item = "M";
      }
      if (this.dataProgress.requestItem == "FM") {
        item = "F";
      }
      if (data != "") {
        let str = data[0].analysisReportNo.split("-");
        let str2 = str[2].split("");
        let useStr = str2[0] + str2[1] + str2[2] + str2[3];
        let Num = + useStr + 1;
        let Str = "" + Num;
        let NewItem = "";
        if (Str.length == 1) {
          NewItem = "000" + Num + item;
        } else if (Str.length == 2) {
          NewItem = "00" + Num + item;
        } else if (Str.length == 3) {
          NewItem = "0" + Num + item;
        }

        this.htmlReportNo = this.year2dit + "-" + "T2" + "-" + NewItem;
      } else {

        this.htmlReportNo = this.year2dit + "-" + "T2" + "-0001" + item;
      }
    })
  }

  findMemberAll() {
    this.progressForm5.findMember().subscribe((data: any) => {
      if (data) {
        this.memberAll = data;
        // console.log(data);
      }
    })
  }

  addToList() {
    this.emailPush.push(this.htmlInform);
    this.htmlInform = "";

  }

  delToList(i) {
    this.emailPush.splice(i, 1);
  }

  browsFile(event) {

    this.fileUpload.push(event.target.files[0]);
    // this.fileName.push(event.target.files[0].name);
    console.log(this.fileUpload);
    // console.log(this.fileName);

  }

  delFile(i) {
    this.fileUpload.splice(i, 1);
  }

  upLoadFiles() {

    this.fileUpload.forEach(i => {
      var fd: any = new FormData();
      var name = this.htmlReportNo + "-" + i.name;
      console.log("NAME NEW-> " + name);
      fd.append("file", i, name);
      this.progressForm5.UPFILE(fd).subscribe((data: any) => {

      })
    });

  }

  submitInform(){

    this.emailPush.forEach(i => {
      console.log("submitInform ->> " + i);
      let Data = {
        analysisReportNo: this.htmlReportNo,
        name: i
      }
      this.progressForm5.submitInform(Data).subscribe((data:any)=>{
        
      })
    });
  }


}
