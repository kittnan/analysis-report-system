import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class ProgressForm5Service {

  constructor(private http: HttpClient) { }

  getProgressForm1(data:any): Observable<any>{
    return this.http.post("http://localhost:4013/getProgressForm1",data);
  }
  submitReport(data:any): Observable<any>{
    return this.http.post("http://localhost:4013/submitReport",data);
  }
  submitInform(data:any): Observable<any>{
    return this.http.post("http://localhost:4013/submitInform",data);
  }
  getEng(data:any): Observable<any>{
    return this.http.post("http://localhost:4013/getEng",data);
  }
  getLists(data:any): Observable<any>{
    return this.http.post("http://localhost:4013/getLists",data);
  }
  findReport(): Observable<any>{
    return this.http.get("http://localhost:4013/findReport");
  }
  findMember():Observable<any>{
    return this.http.get("http://localhost:4013/findMember");
  }
  UPFILE(data:any):Observable<any>{
    return this.http.post("http://localhost:4013/UPFILE",data);
  }

  submitProgress(data:any): Observable<any>{
    return this.http.post("http://localhost:4013/submitProgress",data);
  }

  
  
}
