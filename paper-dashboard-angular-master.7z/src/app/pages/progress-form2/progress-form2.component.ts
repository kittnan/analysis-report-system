import { Component, OnInit } from '@angular/core';
import { ProgressForm2Service } from './progress-form2.service';

@Component({
  selector: 'app-progress-form2',
  templateUrl: './progress-form2.component.html',
  styleUrls: ['./progress-form2.component.css']
})
export class ProgressForm2Component implements OnInit {

  dataProgress: any;
  submitProgressForm: any;
  htmlDate2: any;

  userStatus: any;
  formStatus: any;

  constructor(private progressForm2: ProgressForm2Service) { }

  ngOnInit(): void {
    window.scrollTo(0, 0);
    let Data = {
      title: sessionStorage.getItem('numberProgress1')
    }
    this.progressForm2.getProgressForm1(Data).subscribe((data) => {

      if (data) {
        this.dataProgress = data[0];
        this.formStatus = data[0].status;
        this.userStatus = sessionStorage.getItem('userStatus');
        // console.log(this.dataProgress);
      }
    })
  }

  submitForm(e) {
    if (e.value == "reject") {
      let Data = {
        requestNumber: sessionStorage.getItem('numberProgress1'),
        status: 3.1
      }
      this.progressForm2.submitProgress(Data).subscribe((data: any) => {
        if (data) {
          // console.log("OKOKOKOKO");
        }
      })
    } else {
      if ( this.htmlDate2 != null) {

        let Data = {
          requestNumber: sessionStorage.getItem('numberProgress1'),
          status: 3,
          replyDate: this.htmlDate2
        }
        this.progressForm2.submitProgress(Data).subscribe((data: any) => {
          if (data) {
            alert("SUCCESS");
            location.href = "/#manageForm";
          }
        })
      } else{
        alert("Fail");
        window.scroll(0, 0);

      }
    }
  }

}
