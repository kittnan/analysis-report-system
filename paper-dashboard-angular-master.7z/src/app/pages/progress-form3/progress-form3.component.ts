import { Component, OnInit } from '@angular/core';
import { ProgressForm3Service } from './progress-form3.service';
@Component({
  selector: 'app-progress-form3',
  templateUrl: './progress-form3.component.html',
  styleUrls: ['./progress-form3.component.css']
})
export class ProgressForm3Component implements OnInit {

  dataProgress: any;
  userStatus: any;
  formStatus: any;

  engAll: any;

  htmlEng: any;

  constructor(private progressForm3: ProgressForm3Service) { }

  ngOnInit(): void {
    let Data = {
      title: sessionStorage.getItem('numberProgress1')
    }
    this.progressForm3.getProgressForm1(Data).subscribe((data) => {

      // console.log(">> " +data[0]);
      if (data) {
        this.dataProgress = data[0];
        this.formStatus = data[0].status;
        this.userStatus = sessionStorage.getItem('userStatus');

        this.loadEng();
      }
    })
  }

  // ? function load Eng list all
  loadEng() {
    let Data = {
      title: "Engineer"
    };
    this.progressForm3.getEng(Data).subscribe((data: any) => {
      if (data) {
        this.engAll = data;
      }
    })
  }

  submitForm() {
    // ? ดัก สเตตัสของ ฟอร์ม
    if (this.formStatus != 5) {

      let Data = {
        engineer: this.htmlEng,
        requestNumber: sessionStorage.getItem('numberProgress1'),
        status: 4
      }
      this.progressForm3.submitProgress(Data).subscribe((data: any) => {
        if (data) {
          alert("OK Status 4");
          location.href = "/#manageForm";
        }
      })
    } else {

    }
  }

}
