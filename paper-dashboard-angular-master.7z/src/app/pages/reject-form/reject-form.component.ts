import { Component, OnInit } from '@angular/core';
import { RejectFormService } from './reject-form.service';

@Component({
  selector: 'app-reject-form',
  templateUrl: './reject-form.component.html',
  styleUrls: ['./reject-form.component.css']
})
export class RejectFormComponent implements OnInit {
  
  

  constructor(private rejectForm: RejectFormService) { }

  ngOnInit(): void {

  }

}
