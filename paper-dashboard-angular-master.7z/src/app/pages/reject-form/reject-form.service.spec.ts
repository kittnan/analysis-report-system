import { TestBed } from '@angular/core/testing';

import { RejectFormService } from './reject-form.service';

describe('RejectFormService', () => {
  let service: RejectFormService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RejectFormService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
