import { Component, OnInit } from '@angular/core';
import { ManageService } from './manage.service';
export interface RouteInfo {
  path: string;
  title: string;
  class: string;
}

export const ROUTES: RouteInfo[] = [
  { path: '/dashboard', title: '1', class: '' },
  { path: '/manage', title: 'm1', class: '' },
  { path: '/manage2', title: 'm2', class: '' },
  { path: '/manage3', title: 'm3', class: '' },
  { path: '/manage4', title: 'm4', class: '' },
  { path: '/manage5', title: 'm5', class: '' },
  { path: '/manage6', title: 'm6', class: '' },
];
@Component({
  selector: 'app-manage',
  templateUrl: './manage.component.html',
  styleUrls: ['./manage.component.css']
})
export class ManageComponent implements OnInit {
  public menuItems: any[];

  constructor(private manage: ManageService) { }

  requestForm: any;
  
  ngOnInit(): void {
   

  }

  getMaster() {
    let Data = {
      
    }
    this.manage.getRequestForm(Data).subscribe((data: any) => {
        if (data) {
            this.requestForm = data; // รับ List Master All มา
        } else {
            location.reload();
        }
    })
}

}


