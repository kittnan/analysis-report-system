import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { AdminLayoutRoutes } from './admin-layout.routing';

import { DashboardComponent }       from '../../pages/dashboard/dashboard.component';
import { UserComponent }            from '../../pages/user/user.component';
import { TableComponent }           from '../../pages/table/table.component';
import { TypographyComponent }      from '../../pages/typography/typography.component';
import { IconsComponent }           from '../../pages/icons/icons.component';
import { MapsComponent }            from '../../pages/maps/maps.component';
import { NotificationsComponent }   from '../../pages/notifications/notifications.component';
import { UpgradeComponent }         from '../../pages/upgrade/upgrade.component';
import { RequestFormComponent }     from '../../pages/request-form/request-form.component';
import { ManageComponent }          from '../../pages/manage/manage.component';
import { Manage3Component }          from '../../pages/manage3/manage3.component';
import { Manage4Component }          from '../../pages/manage4/manage4.component';
import { Manage5Component }          from '../../pages/manage5/manage5.component';
import { Manage6Component }          from '../../pages/manage6/manage6.component';
import { MasterlistsComponent }      from 'app/pages/masterlists/masterlists.component';
import { ManageFormComponent }       from 'app/pages/manage-form/manage-form.component';
import { RejectFormComponent } from 'app/pages/reject-form/reject-form.component';
import { ProgressForm1Component } from 'app/pages/progress-form1/progress-form1.component';
import { ProgressForm2Component } from 'app/pages/progress-form2/progress-form2.component';
import { ProgressForm3Component } from 'app/pages/progress-form3/progress-form3.component';
import { ProgressForm4Component } from 'app/pages/progress-form4/progress-form4.component';
import { ProgressForm5Component } from 'app/pages/progress-form5/progress-form5.component';
import { ProgressForm6Component } from 'app/pages/progress-form6/progress-form6.component';
import { LoginComponent } from 'app/pages/login/login.component';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(AdminLayoutRoutes),
    FormsModule,
    NgbModule
  ],
  declarations: [
    DashboardComponent,
    UserComponent,
    TableComponent,
    UpgradeComponent,
    TypographyComponent,
    IconsComponent,
    MapsComponent,
    NotificationsComponent,
    RequestFormComponent,
    ManageComponent,
    ProgressForm1Component,
    ProgressForm2Component,
    ProgressForm3Component,
    ProgressForm4Component,
    ProgressForm5Component,
    ProgressForm6Component,
    Manage3Component,
    Manage4Component,
    Manage5Component,
    Manage6Component,
    MasterlistsComponent,
    ManageFormComponent,
    RejectFormComponent,
    LoginComponent
  ]
})

export class AdminLayoutModule {}
